@echo off
setlocal enabledelayedexpansion

REM =====================================================
REM CONFIGURATION
REM =====================================================
set "UNSIGN_DIR=D:\Java\bitdreamit-astm\unsign\bitdreamit-astm"
set "SIGN_DIR=D:\Java\bitdreamit-astm\sign\bitdreamit-astm"
set "JKS_FILE=%SIGN_DIR%\mykeystore.jks"
set "P12_FILE=%SIGN_DIR%\mykeystore.p12"
set "STOREPASS=bitdreamit"
set "KEYPASS=bitdreamit"
set "ALIAS=mykey"
set "VALIDITY_DAYS=3650"
set "TIMESTAMP_URL=http://timestamp.digicert.com"

REM JAVA_HOME must be set in your environment
if "%JAVA_HOME%"=="" (
    echo ERROR: JAVA_HOME is not set
    exit /b 1
)

REM =====================================================
REM CREATE SIGN DIRECTORY
REM =====================================================
if exist "%SIGN_DIR%" rmdir /s /q "%SIGN_DIR%"
mkdir "%SIGN_DIR%"

REM =====================================================
REM COPY UNSIGNED JARS TO SIGN DIRECTORY
REM =====================================================
xcopy "%UNSIGN_DIR%\*" "%SIGN_DIR%\" /E /I /Y >nul

cd "%SIGN_DIR%"

REM =====================================================
REM CREATE JKS KEYSTORE
REM =====================================================
if not exist "%JKS_FILE%" (
    echo Generating JKS keystore...
    "%JAVA_HOME%\bin\keytool" -genkeypair ^
        -alias %ALIAS% ^
        -keyalg RSA ^
        -keysize 2048 ^
        -validity %VALIDITY_DAYS% ^
        -keystore "%JKS_FILE%" ^
        -storepass %STOREPASS% ^
        -keypass %KEYPASS% ^
        -dname "CN=Bit Dream IT ASTM Plugin, OU=Development, O=Bit Dream IT, C=BD" ^
        -storetype JKS
)

REM =====================================================
REM CONVERT JKS TO PKCS12
REM =====================================================
echo Converting JKS to PKCS12...
"%JAVA_HOME%\bin\keytool" -importkeystore ^
    -srckeystore "%JKS_FILE%" ^
    -destkeystore "%P12_FILE%" ^
    -deststoretype PKCS12 ^
    -srcstorepass %STOREPASS% ^
    -deststorepass %STOREPASS% ^
    -srcalias %ALIAS% ^
    -destalias %ALIAS% ^
    -srckeypass %KEYPASS% ^
    -destkeypass %KEYPASS% ^
    -noprompt

REM =====================================================
REM CLEAN OLD SIGNATURES AND REPACK JARS PROPERLY
REM =====================================================
echo Removing old signatures from JARs...
for %%J in (astm-client.jar astm-server.jar astm-shared.jar lib\AsyncAstm-3.2.jar) do (
    if exist "%%J" (
        echo Processing %%J
        set "JAR_NAME=%%~nJ"
        set "JAR_PATH=%%J"
        
        REM Create a temporary directory for extraction
        set "TEMP_DIR=%SIGN_DIR%\temp_!JAR_NAME!"
        if exist "!TEMP_DIR!" rmdir /s /q "!TEMP_DIR!"
        mkdir "!TEMP_DIR!"
        
        REM Extract jar to temp directory
        cd "!TEMP_DIR!"
        "%JAVA_HOME%\bin\jar" xf "%SIGN_DIR%\!JAR_PATH!"
        
        REM Remove ONLY signature files, NOT the entire META-INF folder
        if exist META-INF\*.SF del META-INF\*.SF 2>nul
        if exist META-INF\*.RSA del META-INF\*.RSA 2>nul
        if exist META-INF\*.DSA del META-INF\*.DSA 2>nul
        if exist META-INF\*.EC del META-INF\*.EC 2>nul
        if exist META-INF\SIG-* del META-INF\SIG-* 2>nul
        
        REM Keep the MANIFEST.MF file - DO NOT DELETE IT
        
        REM Create new jar with -signed suffix
        echo Creating new jar: !JAR_NAME!-signed.jar
        "%JAVA_HOME%\bin\jar" cfm "%SIGN_DIR%\!JAR_NAME!-signed.jar" META-INF\MANIFEST.MF *
        
        REM Clean up temp directory
        cd "%SIGN_DIR%"
        rmdir /s /q "!TEMP_DIR!"
        
        REM Delete original unsigned jar
        del "!JAR_PATH!" 2>nul
    )
)

REM =====================================================
REM SIGN JARS WITH PKCS12 KEYSTORE
REM =====================================================
echo.
echo Signing JAR files...
for %%J in (astm-client-signed.jar astm-server-signed.jar astm-shared-signed.jar lib\AsyncAstm-3.2-signed.jar) do (
    if exist "%%J" (
        echo Signing %%J
        "%JAVA_HOME%\bin\jarsigner" ^
            -keystore "%P12_FILE%" ^
            -storetype PKCS12 ^
            -storepass %STOREPASS% ^
            -keypass %KEYPASS% ^
            -tsa %TIMESTAMP_URL% ^
            -verbose ^
            "%%J" %ALIAS%
        
        if errorlevel 1 (
            echo ERROR signing %%J
            exit /b 1
        )
        echo.
    )
)

REM =====================================================
REM VERIFY SIGNATURES AND CHECK META-INF CONTENTS
REM =====================================================
echo Verifying signatures and checking files...
for %%J in (astm-client-signed.jar astm-server-signed.jar astm-shared-signed.jar lib\AsyncAstm-3.2-signed.jar) do (
    if exist "%%J" (
        echo Checking %%J
        
        REM Verify signature
        "%JAVA_HOME%\bin\jarsigner" -verify "%%J" >nul
        if errorlevel 1 (
            echo SIGNATURE VERIFICATION FAILED: %%J
            exit /b 1
        )
        
        REM List contents of META-INF to confirm files are present
        echo Contents of META-INF in %%J:
        "%JAVA_HOME%\bin\jar" tf "%%J" | findstr /i "META-INF\\" | findstr /i "\.SF$ \.RSA$ MANIFEST.MF"
        echo.
    )
)

REM =====================================================
REM ALTERNATIVE: SIMPLER APPROACH - JUST SIGN WITHOUT REPACKAGING
REM =====================================================
REM If the above still doesn't work, try this simpler approach:
REM Instead of extracting and repackaging, just sign the original jars directly
REM This preserves all original files including manifests

REM Uncomment the following section and comment out the extraction/repackaging section above:

REM echo Removing old signatures from JARs...
REM for %%J in (astm-client.jar astm-server.jar astm-shared.jar lib\AsyncAstm-3.2.jar) do (
REM     if exist "%%J" (
REM         echo Removing signatures from %%J
REM         "%JAVA_HOME%\bin\jar" uf "%%J" -M
REM         move "%%J" "%%~nJ-signed.jar" >nul
REM     )
REM )

REM =====================================================
REM CREATE ZIP PACKAGE
REM =====================================================
echo.
echo Creating plugin ZIP...

set "FINAL_ZIP=%SIGN_DIR%\bitdreamit-astm.zip"

REM Delete final ZIP if exists
if exist "%FINAL_ZIP%" del /q "%FINAL_ZIP%"

REM Use 7-Zip if available, otherwise use PowerShell
where 7z >nul 2>nul
if %errorlevel% equ 0 (
    echo Using 7-Zip to create archive...
    7z a -tzip "%FINAL_ZIP%" "%SIGN_DIR%\*" -r >nul
) else (
    echo Using PowerShell to create archive...
    powershell -Command "Compress-Archive -Path '%SIGN_DIR%\*' -DestinationPath '%FINAL_ZIP%' -Force"
)

if not exist "%FINAL_ZIP%" (
    echo ERROR: Failed to create ZIP file
    exit /b 1
)

echo.
echo =========================================
echo ALL JARS SIGNED AND VERIFIED SUCCESSFULLY
echo ZIP created: %FINAL_ZIP%
echo =========================================
echo.
dir "%FINAL_ZIP%" | find "File(s)"
echo.
pause